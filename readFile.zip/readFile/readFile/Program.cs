﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace readFile
{
    class Program
    {
        private static string help;
        private static string copyNum;

        private static double vn_x;
        private static double vn_y;
        private static double vn_z;

        private static double vt_x;
        private static double vt_y;

        private static double v_x;
        private static double v_y;
        private static double v_z;

        private static string f_x;
        private static string f_y;
        private static string f_z;

        static void Main(string[] args)
        {
            string[] openFile = File.ReadAllLines("car.obj");

            string[] myMass = null;

            Program program = new Program();



            for (int i = 0; i <= openFile.Length; i++)
            {
                myMass = openFile[i].Split(new char[] { ' ' }, 1);
                foreach (string line in myMass)
                {
                    if (line.StartsWith("vt"))
                    {
                        help = line.Substring(3);
                        program.body(1, "vt");

                    }
                    else if (line.StartsWith("vn"))
                    {
                        help = line.Substring(3);
                        program.body(2, "vn");
                    }
                    else if (line.StartsWith("v"))
                    {
                        help = line.Substring(2);
                        program.body(2, "v");

                    }
                    else if (line.StartsWith("f"))
                    {
                        help = line.Substring(2);
                        program.body(2, "f");
                    }
                }
            }
        }


        private void body(int number, string type)
        {
            help = help.Replace(".", ",");

            Console.WriteLine("all->" + help);
            for (int j = 0; j <= number; j++)
            {
                if (j == 0)
                {
                    copyNum = help.Substring(0, help.IndexOf(" "));

                    if (type == "vt")
                    {
                        vt_x = double.Parse(copyNum);
                        Console.WriteLine("x->" + vt_x);
                    }
                    else if (type == "vn")
                    {
                        vn_x = double.Parse(copyNum);
                        Console.WriteLine("x->" + vn_x);
                    }
                    else if (type == "f")
                    {
                        f_x = copyNum;
                        Console.WriteLine("x->" + f_x);
                    }
                    else //v
                    {
                        v_x = double.Parse(copyNum);
                        Console.WriteLine("x->" + v_x);
                    }

                    help = help.Substring(copyNum.Length + 1);
                }
                else if (j == 1)
                {
                    if (number == 1 || type == "vt")
                    {
                        vt_y = double.Parse(copyNum);
                        Console.WriteLine("y->" + vt_y);
                    }
                    else
                    {
                        copyNum = help.Substring(0, help.IndexOf(" "));
                        if (type == "vn")
                        {
                            vn_y = double.Parse(copyNum);
                            Console.WriteLine("x->" + vn_y);
                        }
                        else if (type == "f")
                        {
                            f_y = copyNum;
                            Console.WriteLine("y->" + f_y);
                        }
                        else //v
                        {
                            v_y = double.Parse(copyNum);
                            Console.WriteLine("x->" + v_y);
                        }
                        help = help.Substring(copyNum.Length + 1);
                    }   
                } 
                else if (j == 2)
                {
                    if (type == "vn")
                    {
                        vn_z = double.Parse(help);
                        Console.WriteLine("z->" + vn_z);
                    }
                    else if (type == "f")
                    {
                        f_z = help;
                        Console.WriteLine("z->" + f_z);
                    }
                    else // v
                    {
                        v_z = double.Parse(help);
                        Console.WriteLine("z->" + v_z);
                    }
                    
                }
            }
        }
    }
}
